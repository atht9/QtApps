#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QVector>
#include<QDebug>
#include<math.h>
int tailleserie(0);
double moy,vari,ecty;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_addelmt_clicked()
{
   ui->seriestat->insertColumn(1);
   tailleserie++;
}

void MainWindow::on_rmelemt_clicked()
{
    ui->seriestat->removeColumn(1);
    tailleserie--;
    }

void MainWindow::on_cmax_clicked()
{
    QVector<double>valeurs;
    double N(tailleserie+1);

         for(int j(0);j<N;j++)
               {
                   QTableWidgetItem *elem = ui->seriestat->item(0,j);
                    valeurs.push_back(elem->text().toDouble());
               }

    int mx(0);
    for(int j(0);j<valeurs.size();j++)
          {
              qDebug()<<"Element :"<<valeurs[j];
              if(valeurs[j]>mx) mx=valeurs[j];
          }
    qDebug()<<"Votre max c'est :"<<mx<<endl;
    ui->maxi->setNum(mx);
}



void MainWindow::on_cmin_clicked()
{

    QVector<double>valeurs;
    double N(tailleserie+1);

         for(int j(0);j<N;j++)
               {
                   QTableWidgetItem *item = ui->seriestat->item(0,j);
                    valeurs.push_back(item->text().toDouble());
               }

    int mn(valeurs.front());
    for(int j(0);j<valeurs.size();j++)
          {
              if(valeurs[j]<mn) mn=valeurs[j];
          }
    qDebug()<<"Votre min c'est :"<<mn<<endl;
    ui->mini->setNum(mn);

}

void MainWindow::on_cmoyenne_clicked()
{
    QVector<double>valeurs;
    double N(tailleserie+1);

         for(int j(0);j<N;j++)
               {
                   QTableWidgetItem *item = ui->seriestat->item(0,j);
                    valeurs.push_back(item->text().toDouble());
               }
    double s(0);
    for(int j(0);j<valeurs.size();j++)
          {
              s+=valeurs[j];
          }
    qDebug()<<"somme des elmts c'est "<<s;
    qDebug()<<"taille c'est "<<valeurs.size();
    qDebug()<<"moyenne c'est "<<s/valeurs.size();


    ui->moyenne->setNum(s/valeurs.size());
    moy=s/valeurs.size();
}


void MainWindow::on_cvariance_clicked()
{
    QVector<double>valeurs;
    double N(tailleserie+1);

         for(int j(0);j<N;j++)
               {
                   QTableWidgetItem *item = ui->seriestat->item(0,j);
                    valeurs.push_back(item->text().toDouble());
               }
    int s(0);
    for(int j(0);j<valeurs.size();j++)
          {
        s+=(valeurs[j]-moy)*(valeurs[j]-moy);
    }
    ui->variance->setNum(s/valeurs.size());
    vari=s/valeurs.size();
}



void MainWindow::on_cecarttype_clicked()
{
    ui->ecarttype->setNum(sqrt(vari));
}

void MainWindow::on_coefvar_clicked()
{
    ui->rcoefvar->setNum(sqrt(vari)/moy);
}
