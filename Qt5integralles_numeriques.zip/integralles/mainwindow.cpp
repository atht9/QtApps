#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<iostream>
#include<QMainWindow>
#include<QtDebug>
#include<QFileInfo>
#include<vector>
#include<math.h>
#include<tinyexpr.h>
#include<cstdio>
using namespace std;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //QString myString = ui->ufonction->text();
    //const char* myChar = myString.toStdString().c_str();
    //qDebug()<<myChar;


}

MainWindow::~MainWindow()
{
    delete ui;
}

double MainWindow::f(double a){
    QString myString = ui->ufonction->text();
    const char* myChar = myString.toStdString().c_str();
    double x,y;
        te_variable vars[] = {{"x", &x}, {"y", &y}};
        int err;
      te_expr *expr = te_compile(myChar, vars, 2, &err);
      if (expr) {
          x=a;
          y=0;
          const double h1 = te_eval(expr);
          return h1;
          te_free(expr);
      } else { qDebug()<<"error at"<<err;
         printf("\t%*s^\nError near here", err-1, "");

      }

}




void MainWindow::on_pushButton_clicked()
{
    QString myString = ui->ufonction->text();
    const char* myChar = myString.toStdString().c_str();
    qDebug()<<myChar;
    double a,b;
    QString aString =ui->bornea->text();
    a = aString.toDouble();
    QString bString =ui->borneb->text() ;
    b = bString.toDouble();
    int n(10000);
    float h((b-a)/n);
    double somme = 0.0;

    for(int k=0; k<=n; k++)
        if(k%2 == 0)
            somme += 2*f(a+k*h);
        else
            somme += 4*f(a+k*h);

    double resultat = ( f(a) + somme + f(b) )*h/3;

    ui->result->setNum(resultat);
}



void MainWindow::on_ufonction_textChanged(const QString &fct)
{

}

void MainWindow::on_trapezes_clicked()
{
    QString myString = ui->ufonction->text();
    const char* myChar = myString.toStdString().c_str();
    qDebug()<<myChar;
    double a,b;
    QString aString =ui->bornea->text() ;
    a = aString.toDouble();
    QString bString =ui->borneb->text() ;
    b = bString.toDouble();
    int n(10000);
    double h = (b-a)/n;
    double somme = 0.0;
    for(int k=0; k<n; k++)
        somme += ( f(a+k*h) + f(a+(k+1)*h) )/2;

    double resultat=somme*h;
    ui->result->setNum(resultat);
}

void MainWindow::on_rectangle_clicked()
{
    QString myString = ui->ufonction->text();
    const char* myChar = myString.toStdString().c_str();
    qDebug()<<myChar;
    double a,b;
    QString aString =ui->bornea->text() ;
    a = aString.toDouble();
    QString bString =ui->borneb->text() ;
    b = bString.toDouble();
    int n(10000);
    double h = (b-a)/n;
    double somme = 0.0;
    for(int k=0; k<n; k++)
        somme += ( f(a+k*h+0.5*h) );

    double resultat=somme*h;
    ui->result->setNum(resultat);
}



void MainWindow::on_stef_clicked()
{
    QString myString = ui->ufonction->text();
    const char* myChar = myString.toStdString().c_str();
    qDebug()<<myChar;
    double a,b;
    QString aString =ui->bornea->text() ;
    a = aString.toDouble();
    QString bString =ui->borneb->text() ;
    b = bString.toDouble();
    //int n(10000);
    //double h = (b-a)/n;
    double terme1 = 4*f( (3*a+b)/4 ) ;
    double terme2 = 2*f( (a+b)/2 ) ;
    double terme3 = 2*f((a+3*b)/4) ;

    double resultat = (terme1 + terme2 + terme3)*(b-a)/6;
    ui->result->setNum(resultat);

}




