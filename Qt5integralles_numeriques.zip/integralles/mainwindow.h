#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<math.h>
#include<iostream>
#include<QMainWindow>
#include<QtDebug>
#include<QFileInfo>
#include <QDebug>
#include<vector>
#include<math.h>
#include<tinyexpr.h>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();
    double f(double);
    void on_ufonction_textChanged(const QString &arg1);

    void on_trapezes_clicked();

    void on_rectangle_clicked();

    void on_stef_clicked();



    void on_label_linkActivated(const QString &link);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
